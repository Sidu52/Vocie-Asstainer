import './MainScreen.css'
import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { URL } from '../endpointURL';
import { MyContext } from "../Context/Mycontext";
import PopupTour from '../Component/PopTour/PopupTour'
import { speakText } from "../Component/text_to_speack/speaktext";
import { FaMicrophone, FaMicrophoneSlash } from 'react-icons/fa';
import { startListening } from './MainVoiceFuntion';
import { takeInput } from './MainVoiceFuntion';
import { find } from './MainVoiceFuntion';
import { IoCloseCircleOutline } from 'react-icons/io5'
import alarmImage from '../assets/Images/alarmB.gif'

const MainScreen = () => {
    const localuser = JSON.parse(localStorage.getItem('user'));
    const [alarmRing, setAlarmRing] = useState(false);
    const [alardetail, setAlarmDeatil] = useState({});
    const [abortController, setAbortController] = useState(new AbortController());
    const { showScreen, setShowScreen, listen, setListen, load } = useContext(MyContext);
    const [listening, setListening] = useState(false);
    const [userInput, setUserInput] = useState("");
    const [tourToggle, setTourToggle] = useState(true);

    useEffect(() => {
        const userInput = "Hello what is your name";
        axios.post(`${URL}/findfunction`, { userInput })
            .then(response => {
                console.log(response.data);
            })
            .catch(error => {
                console.error(error);
            });
        getAllAlarm()
    }, [load]);

    useEffect(() => {
        if (listen) {
            setShowScreen(null)
            takeinputcall("");
        }
    }, [listen])

    //Set Alarms 
    const getAllAlarm = () => {
        if (!localuser) {
            return;
        }
        axios.post(`${URL}/alarm/getalarm`, { userid: localuser._id })
            .then(response => {
                const data = response.data?.data;
                if (data && data.length > 0) {
                    const timeDifferences = [];
                    data.forEach((alarmData, index) => {
                        const givenTime = alarmData.alarmTime;
                        const [time, period] = givenTime.split(' ');
                        const [hours, minutes] = time.split(':');
                        const formattedGivenTime = new Date();
                        formattedGivenTime.setHours(
                            period.toLowerCase() === 'p.m.' ? parseInt(hours) + 12 : parseInt(hours),
                            parseInt(minutes),
                            0,
                            0
                        );
                        const currentTime = new Date();
                        let timeDifference = formattedGivenTime - currentTime;
                        if (timeDifference < 0) {
                            timeDifference += 24 * 60 * 60 * 1000; // 24 hours in milliseconds
                        }
                        timeDifferences.push(timeDifference);
                        setTimeout(() => {
                            // Assuming setAlarmRing and setAlarmDeatil are functions
                            setAlarmRing(true);
                            setAlarmDeatil(alarmData);
                        }, timeDifference);
                    });

                    return timeDifferences;
                }
            })
            .catch(error => {
                console.error('Error fetching alarm data:', error);
            });
    };

    const takeinputcall = async (value) => {
        let input = value || "";
        if (input == "") {
            input = await takeInput();
        }
        if (input?.toLowerCase().includes("jarvis stop") || input?.toLowerCase().includes("stop jarvis") || input?.toLowerCase().includes("close jarvis") || input?.toLowerCase().includes("jarvis close")) {
            await speakText("okay Boss, next time just say 'Hello Jarvis,' and I am always ready for you");
            return handleClosetour();
        }
        else if (input || input != "") {
            setUserInput(input);
            const output = await find(input);
            setShowScreen(output)
            setListen(false)
        } else {
            takeinputcall()
        }
    }


    const handleClosetour = async (value) => {
        setTourToggle(value)
        handlemainListen("")
    }

    const handlemainListen = async (value) => {

        const data = await startListening(value, listening);
        if (data) {
            setListening(true)
            await speakText("Hy Boss what should i do for you");
            setListen(true)
        }
    }

    const handleClick = async () => {
        abortController.abort();
        // Create a new AbortController for the next operation
        const newAbortController = new AbortController();
        setAbortController(newAbortController);
        try {
            setShowScreen(false)
            await takeInput()
        } catch (error) {
            console.error(error.message);
            // Handle error as needed
        }
    };

    return (
        <div className='contai'>\
            <div className="w-full h-0 bg-opacity-75 bg-gray-800 absolute text-center flex items-center transition-all duration-500 justify-center z-10 overflow-hidden" style={{ height: alarmRing ? "100%" : "" }} >
                <div className='flex items-center justify-around bg-white rounded-2xl relative'>
                    <IoCloseCircleOutline className=' absolute top-4 right-4 text-2xl' onClick={async () => {
                        setAlarmRing(false)
                        await axios.post(`${URL}/alarm/deletealarm`, { alarmTime: alardetail.alarmTime, userid: localuser._id });
                    }
                    }
                    />
                    <img className='w-1/3' src={alarmImage} alt="" />
                    <div className=' text-left'>
                        <h2 className='text-4xl font-bold'>{alardetail?.title || "SSS"}</h2>
                        <p className='text-xl font-semibold'>{alardetail?.alarmTime || "10:30 p.m"}</p>
                    </div>
                </div>
                {alarmRing ? <audio src="https://2u039f-a.akamaihd.net/downloads/ringtones/files/mp3/technocraj-20230730-0001-61126.mp3" autoPlay loop></audio> : null}

            </div>
            <div className="main__container">
                {
                    tourToggle ? <PopupTour handleClosetour={handleClosetour} /> : null
                }
                <div className='main__Svg__Container'>
                    <div className='main__SVg__inner__Container'>
                        {listening ? <FaMicrophone onClick={() => {
                            setShowScreen(false)
                            setListening(false)
                            takeinputcall("Jarvis stop")
                        }} /> : <FaMicrophoneSlash onClick={() => {
                            setListening(true)
                            // startListening()
                            handlemainListen("jarvis")
                        }}
                        />}
                    </div>
                    <svg width="210" height="210" id="jarvis-like">
                        <defs>
                            <filter id="light-circle">
                                <feGaussianBlur result="blurred" in="SourceGraphic" stdDeviation="1" />
                            </filter>
                        </defs>
                        <circle cx="105" cy="105" r="100" fill="transparent" stroke="#B4F6FB" strokeWidth="2" strokeDasharray="50, 5">
                            <animateTransform attributeName="transform" type="rotate" from="0 105 105" to="-360 105 105" dur="10s" repeatCount="indefinite" />
                        </circle>
                        <circle cx="105" cy="105" r="95" fill="transparent" stroke="#64E6EF" strokeWidth="1.5"></circle>
                        <circle cx="105" cy="105" r="80" fill="transparent" stroke="#B4F6FB" strokeWidth="10" strokeDasharray="2,2.29">
                            <animateTransform attributeName="transform" type="rotate" from="0 105 105" to="360 105 105" dur="10s" repeatCount="indefinite" />
                        </circle>
                        <circle cx="105" cy="105" r="61" fill="transparent" stroke="#B4F6FB" strokeWidth="2" strokeDasharray="50, 25">
                            <animateTransform attributeName="transform" type="rotate" from="0 105 105" to="-360 105 105" dur="10s" repeatCount="indefinite" />
                        </circle>
                        <circle cx="105" cy="105" r="50" fill="transparent" stroke="#64E6EF" strokeWidth="15" filter="url(#light-circle)"></circle>
                        <circle cx="105" cy="105" r="40" fill="transparent" stroke="#64E6EF" strokeWidth="2"></circle>
                    </svg>
                </div>
                <div className='detail__container'>
                    <h1>Voice Assistant Powered By Alston</h1>
                    {listening ? <p>Listening...</p> : <p>"Not listening"</p>}
                    <p>{userInput}</p>
                </div>
            </div>
            {!showScreen ?
                <div className='secound__Screen'>
                    <span className=' cursor-pointer' onClick={handleClick}>Close</span>
                    <div className='flex items-center justify-center overflow-hidden'>
                        {showScreen}
                    </div>
                </div>
                : ""}
        </div>

    );
}
export default MainScreen;


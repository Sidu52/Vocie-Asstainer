import React from 'react'
import MainScreen from './Screen/MainScreen';
export default function App() {
  return (
    <div>
      <MainScreen />
    </div>
  )
}

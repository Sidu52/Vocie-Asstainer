// const URL = "http://localhost:8000"
const URL = "https://voiceasstant.onrender.com";

export { URL }
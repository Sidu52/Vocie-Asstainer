import React, { useRef, useEffect } from 'react'
import './PopupTour.css'
export default function PopupTour({ handleClosetour }) {
    const myButtonRef = useRef();
    // useEffect(() => {
    //     // Trigger click event programmatically
    //     myButtonRef.current.click();
    // }, []); // This effect runs once on mount

    return (
        <div className='popuptour__container'>
            <div className='popuptour__inner__container'>
                <span>This is a AI Voice Assistat Build by Sidhu Alston just say Hello Jarvis or Hyy Jarvis for starting Cmd</span>
                <button onClick={() => handleClosetour(false)} className='popuptou__button'>Ok</button>
            </div>
        </div>
    )
}

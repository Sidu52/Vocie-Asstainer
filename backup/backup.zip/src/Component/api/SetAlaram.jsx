import React, { useRef, useEffect, useContext, useState } from "react";
import { MyContext } from "../../Context/Mycontext";
import { speakText } from "../text_to_speack/speaktext";
import axios from "axios";
import { URL } from "../../endpointURL";
import { takeInput } from "../../Screen/MainVoiceFuntion";

export default function SetAlaram({ userInput, opration }) {
    const [data, setData] = useState([]);
    const { setListen, setLoad } = useContext(MyContext);
    const hasMounted = useRef(false);

    useEffect(() => {
        if (!hasMounted.current) {
            // Only run the effect on the initial mount
            hasMounted.current = true;
            setAlaram();
        }
    }, []);


    async function setAlaram() {
        try {
            // await speakText(`I think you want to ${opration}`);
            let i = 0;
            let updateData = {};
            const timeRegex = /(\d{1,2}:\d{2}\s*[ap]\.m\.)/gi;
            // Search for time patterns in the input strings
            let time = userInput.match(timeRegex);
            if (!time && opration != "getAll Alarm") {
                await speakText(`gave your  ${opration} time`);
                let Atime = await takeInput();
                time = Atime.match(timeRegex);
                i = 0;
                while (!time && i < 5) {
                    console.log(Atime)
                    await speakText("Sorry time not found try again");
                    i++;
                    Atime = await takeInput();
                    time = Atime.match(timeRegex);
                }
                if (i == 5) {
                    await speakText("Sorry input not found thank for using");
                    return setListen(true);
                }
            }
            i = 0;
            var localuser = JSON.parse(localStorage.getItem('user'));
            if (!localuser) {
                await speakText("User not found which name should I save");
                let nickname = await takeInput();
                i = 0;
                while (!nickname && i < 5) {
                    await speakText("Sorry nickname not found try again");
                    i++;
                    nickname = await takeInput();
                }
                if (i == 5) {
                    await speakText("Sorry input not found thank for using");
                    return setListen(true)
                }
                if (nickname) {
                    await speakText(`okay ${nickname}`);
                    const { data } = await axios.post(`${URL}/todo/user`, {
                        nickname: nickname
                    });
                    if (data.data) {
                        localuser = data.data;
                        localStorage.setItem('user', JSON.stringify(localuser));
                    }
                } else {
                    await speakText(`User not found`);
                    return setListen(true)
                }
                localuser = JSON.parse(localStorage.getItem('user'));
            }
            if (opration == "set Alarm") {
                var { data } = await axios.post(`${URL}/alarm/alarm`, { alarmTime: time[0], userid: localuser._id });
                if (data.data) {
                    await speakText(`${time[0]} alarm ${data.data.title} already set`);
                    return setListen(true)
                }
            }
            switch (opration) {
                case "set Alarm":
                    await speakText("what name should i set the alarm");
                    let alarmName = await takeInput();
                    i = 0;
                    while (!alarmName && i < 5) {
                        await speakText("Sorry name not found try again");
                        i++
                        alarmName = await takeInput();
                    }
                    if (i == 5) {
                        await speakText("Sorry input not found thank for using");
                        setListen(true)
                    }
                    var data = await axios.post(`${URL}/alarm/setalarm`, { title: alarmName, alarmTime: time[0], userid: localuser._id });
                    if (data.data) {
                        await speakText(`ok your ${alarmName} alram set ${time}`);
                    } else {
                        await speakText(`your alarm is not shedule`);
                    }
                    break;

                case "update Alarm":
                    const oldtime = time;
                    await speakText("what should you want to update");
                    await speakText("name or time");
                    let updateType = await takeInput();
                    i = 0;
                    while (!updateType && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        updateType = await takeInput();
                    }
                    if (i == 5) {
                        await speakText("Sorry input not found thank for using");
                        return setListen(true)
                    }

                    const sanitizedInput = updateType.split(' ');
                    // Check for keywords
                    // Search for time patterns in the input strings
                    console.log("object", sanitizedInput)
                    let updatedTime = sanitizedInput.match(timeRegex);
                    console.log("object", updatedTime)

                    const timeupdate = sanitizedInput.some(word => ['time'].includes(word.toLowerCase()));
                    const nameupdate = sanitizedInput.some(word => ['name'].includes(word.toLowerCase()));
                    if (timeupdate && !nameupdate) {
                        await speakText("tell me the updated time");
                        let newTime = await takeInput();
                        // Search for time patterns in the input strings
                        time = newTime.match(timeRegex);
                        i = 0;
                        while (!time && i < 5) {
                            await speakText("Sorry time not found try again");
                            i++
                            newTime = await takeInput();
                            time = newTime.match(timeRegex);
                        }
                        if (i == 5) {
                            await speakText("Sorry input not found thank for using");
                            return setListen(true)
                        }

                        updateData = {
                            alarmTime: time[0],
                        }

                    } else if (nameupdate && !timeupdate) {
                        await speakText("tell me the updated name");
                        let newName = await takeInput();
                        // Search for time patterns in the input strings
                        // time = newName.match(timeRegex);
                        i = 0;
                        while (!newName && i < 5) {
                            await speakText("Sorry name not found try again");
                            i++
                            newName = await takeInput();
                        }
                        if (i == 5) {
                            await speakText("Sorry input not found thank for using");
                            return setListen(true)
                        }

                        updateData = {
                            title: newName,
                        }

                    } else if (timeupdate && nameupdate) {
                        await speakText("tell me the updated name");
                        let newName = await takeInput();
                        i = 0;
                        while (!newName && i < 5) {
                            await speakText("Sorry name not found try again");
                            i++
                            newName = await takeInput();
                        }
                        if (i == 5) {
                            await speakText("Sorry input not found thank for using");
                            return setListen(true)
                        }
                        await speakText("tell me the updated time");
                        let newTime = await takeInput();
                        // Search for time patterns in the input strings
                        time = newTime.match(timeRegex);
                        i = 0;
                        while (!time && i < 5) {
                            await speakText("Sorry time not found try again");
                            i++
                            newTime = await takeInput();
                            time = newTime.match(timeRegex);
                        }
                        if (i == 5) {
                            await speakText("Sorry input not found thank for using");
                            return setListen(true)
                        }
                        updateData = {
                            title: newName,
                            alarmTime: time[0]
                        }
                    } else {
                        await speakText("time or name no one found")
                        return setListen(true)
                    }
                    var data = await axios.put(`${URL}/alarm/updatealarm`, { alarmTime: oldtime[0], userid: localuser._id, updateData });
                    if (data.data) {
                        await speakText(`your alarm ${updateData.title} is update`);
                    } else {
                        await speakText(`your alarm is not update`);
                    }
                    break;
                case "delete Alarm":
                    var { data } = await axios.post(`${URL}/alarm/deletealarm`, { alarmTime: time[0], userid: localuser._id });
                    if (data.data) {
                        await speakText(`your alarm  is deleted`);
                    } else {
                        await speakText(`your alarm is not found`);
                        return setLoad(true)
                    }
                    break;
                case "get Alarm":
                    var { data } = await axios.post(`${URL}/alarm/alarm`, { alarmTime: time[0], userid: localuser._id });
                    if (data.data) {
                        await speakText(`your alarm ${data.data.title} `);
                    } else {
                        await speakText(`your alarm is not find`);
                    }
                    break
                case "getAll Alarm":
                    await speakText("Wait your alarms fetch plz wait");
                    var { data } = await axios.post(`${URL}/alarm/getalarm`, { userid: localuser._id });
                    if (data.data) {
                        await speakText(`your alarms is find`);
                        i = 0;
                        while (i < data.data.length) {

                            setData(prevState => ({
                                ...prevState,
                                data: Array.isArray(prevState.data) ? [...prevState.data, data.data[i]] : [data.data[i]]
                            }));
                            await speakText(`your ${data.data[i].alarmTime} alarm task is ${data.data[i].title}`);
                            i++;
                        }
                    } else {
                        await speakText(`your alarm is not find`);
                    }
                    break;
                default:
                    await speakText("Sorry, I don't know much more about that, but with time I am updating myself");
                    break;
            }
            setLoad(true)
            return setListen(true)
        } catch (err) {
            console.log(err)
            await speakText("Somting wrong with us")
            return setListen(true)
        }
        // Regular expression to match time in the format hh:mm am/pm
    }
    console.log("object", data)
    return (
        <div className="bg-gray-200 p-4 m-4 mt-0 pt-0 rounded max-h-80 min-w-96 relative overflow-y-scroll">
            <h1 className="text-2xl py-3 font-bold  sticky top-0 bg-gray-200 ">Your Alarms</h1>
            <div className="mt-4 ">
                {data?.data?.map((alarm, index) => (
                    <div key={index} className="border p-2 my-2">
                        <p className="text-lg font-semibold">{alarm.alarmTime}</p>
                        <p className="text-sm">{alarm.title}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}

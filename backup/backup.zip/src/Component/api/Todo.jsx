import React, { useState, useRef, useEffect, useCallback, useContext } from "react";
import axios from "axios";
import { MyContext } from "../../Context/Mycontext";
import { speakText } from "../text_to_speack/speaktext";
import { URL } from "../../endpointURL";
import { takeInput } from "../../Screen/MainVoiceFuntion";

const Todo = ({ type }) => {
    const [todo, setTodo] = useState([]);
    const { setListen } = useContext(MyContext)
    const hasMounted = useRef(false);

    useEffect(() => {
        if (!hasMounted.current) {
            // Only run the effect on the initial mount
            hasMounted.current = true;
            fetchTodo(type);
        }
    }, []);

    const fetchTodo = async () => {

        try {
            let i = 0;
            await speakText(`Ok, I think you want to ${type.split('_')[0]} todo`);
            var localuser = JSON.parse(localStorage.getItem('user'));
            if (!localuser) {
                await speakText("User not found if you want to create account gave your nickname");
                let nickname = await takeInput();
                i = 0;
                while (!nickname && i < 5) {
                    await speakText("Sorry nickname not found try again");
                    i++;
                    nickname = await takeInput();
                }
                if (i == 5) {
                    return speakText("Sorry input not found thank for using");
                }
                if (nickname) {

                    await speakText(`You say ${nickname}`);
                    const { data } = await axios.post(`${URL}/todo/user`, {
                        nickname: nickname
                    });

                    if (data.data) {
                        localuser = data.data;
                        localStorage.setItem('user', JSON.stringify(localuser));
                    }
                } else {
                    return await speakText(`User not found`);
                }
                localuser = JSON.parse(localStorage.getItem('user'));
            }
            switch (type) {
                case "create_todolsit":
                    await speakText("What is your to do task");

                    let todoTask = await takeInput();
                    i = 0;
                    while (!todoTask && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        todoTask = await takeInput();
                    }
                    if (i == 5) {
                        return speakText("Sorry input not found thank for using");
                    }

                    var data = await axios.post(`${URL}/todo/todo`, { title: todoTask, completed: false, userid: localuser._id });

                    if (data.data) {
                        await speakText(`ok your task ${todoTask} is added`);
                    } else {
                        await speakText(`your task is not added`);
                    }
                    break;
                case "update_todolsit":
                    await speakText("Which task you want to update");

                    const oldTask = await takeInput();
                    i = 0;
                    while (!oldTask && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        oldTask = await takeInput();
                    }
                    if (i == 5) {
                        return speakText("Sorry input not found thank for using");
                    }

                    await speakText("  Tell what should you want to updated");

                    const updatedTask = await takeInput();
                    i = 0;
                    while (!updatedTask && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        updatedTask = await takeInput();
                    }
                    if (i == 5) {
                        return speakText("Sorry input not found thank for using");
                    }

                    var data = await axios.put(`${URL}/todo/todo`, { title: oldTask, completed: false, userid: localuser._id, updatetitle: updatedTask });

                    if (data.data) {
                        await speakText(`your task ${updatedTask} is update`);
                    } else {
                        await speakText(`your task is not update`);
                    }
                    break;
                case "delete_todolsit":
                    await speakText("Which task you want to delete");

                    let taskname = await takeInput();
                    i = 0;
                    while (!taskname && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        taskname = await takeInput();
                    }
                    if (i == 5) {
                        return speakText("Sorry input not found thank for using");
                    }

                    var data = await axios.post(`${URL}/todo/deletetodo`, { title: taskname, userid: localuser._id });

                    if (data.data) {
                        await speakText(`your task ${taskname} is deleted`);
                    } else {
                        await speakText(`your task is not delted`);
                    }
                    break;
                case "get_todolsit":
                    await speakText("Which task you find in your list");

                    let nam = await takeInput();
                    i = 0;
                    while (!nam && i < 5) {
                        await speakText("Sorry task not found try again");
                        i++
                        nam = await takeInput();
                    }
                    if (i == 5) {
                        return speakText("Sorry input not found thank for using");
                    }

                    var data = await axios.post(`${URL}/todo/utodo`, { title: nam, userid: localuser._id });

                    if (data.data) {
                        await speakText(`your task ${nam} `);
                    } else {
                        await speakText(`your task is not find`);
                    }
                    break
                case "getAll_todolsit":
                    await speakText("Wait your to do list fetch plz wait");

                    var data = await axios.post(`${URL}/todo/gettodo`, { userid: localuser._id });
                    console.log("TodoDAta", data.data.data)
                    // setTodo(data.data.data)
                    if (data.data) {
                        await speakText(`your todos is find`);
                        let i = 0;
                        while (i < data.data.data.length) {

                            console.log(data.data.data[i].title)
                            setTodo(prevTodo => [...prevTodo, data.data.data[i].title]);
                            await speakText(`your ${i + 1} todo task is ${data.data.data[i].title}`);
                            i++;
                        }
                    } else {
                        await speakText(`your task is not find`);
                    }
                    break;
                default:
                    await speakText("Sorry, I don't know much more about that, but with time I am updating myself");
                    break;
            }

            return setListen(true);

        } catch (err) {
            console.error("Error:", err);
            await speakText("Somting Wrong with me try again");
            return setListen(true);
        }
    }

    return (
        <>

            {todo?.length > 0 ? (
                <div className=" bg-gray-200 p-4 m-4 rounded">
                    <h3 className="text-center font-bold text-2xl">Your Todos Task</h3>
                    <ul className="list-disc pl-4">
                        {todo.map((todos, index) => (
                            <li key={index} className="mb-2">{todos.title}</li>
                        ))}
                    </ul>
                </div>

            ) : null}
        </>
    )
}

export default Todo;



import React, { useState, useRef, useEffect, useContext } from "react";
import { MyContext } from "../../Context/Mycontext";
import { speakText } from "../text_to_speack/speaktext";
import { takeInput } from "../../Screen/MainVoiceFuntion";
import axios from 'axios';

export default function Game({ userInput }) {
    const [showwindow, setShowWindow] = useState(false)
    const [gkQuiz, setGkQuize] = useState({ question: "", options: [], correctAns: "" });
    const { setListen, } = useContext(MyContext);
    const hasMounted = useRef(false);

    useEffect(() => {
        if (!hasMounted.current) {
            hasMounted.current = true;
            gameSelect();
        }
    }, []);

    async function gameSelect() {
        const lowerCasedInput = userInput.toLowerCase();

        if (lowerCasedInput.includes("gkquize") || lowerCasedInput.includes("gk quize") || lowerCasedInput.includes("question answer")) {
            await gkquize();
        } else if (lowerCasedInput.includes("number guessing") || lowerCasedInput.includes("number")) {
            await numberGussing();
        } else {
            await speakText("I have two games for you: a general knowledge quiz or a number guessing game. Which one would you to play?");
            let input = await takeInput();
            const lowerCasedInput = input.toLowerCase();

            if (lowerCasedInput.includes("gkquize") || lowerCasedInput.includes("gk quize") || lowerCasedInput.includes("general knowledge") || lowerCasedInput.includes("question answer")) {
                await gkquize();
            } else if (lowerCasedInput.includes("number guessing") || lowerCasedInput.includes("number")) {
                await numberGussing();
            } else {
                await speakText("Sorry, I didn't catch that. Let's try again later. Thanks for stopping by!");
                return setListen(true);
            }
        }
    }



    async function gkquize() {
        try {
            setShowWindow(true);
            var score = 0;
            const { data } = await axios.get("https://the-trivia-api.com/v2/questions");

            for (let i = 0; i < data.length; i++) {
                const question = data[i].question;
                const correctAnswer = data[i].correctAnswer;
                const incorrectAnswers = data[i].incorrectAnswers;

                await speakText("Question");
                setGkQuize({ ...gkQuiz, question: question.text });
                await speakText(question.text);

                const options = ['A', 'B', 'C', 'D'];
                const answers = [...incorrectAnswers, correctAnswer];
                shuffleArray(answers);

                for (let j = 0; j < answers.length; j++) {
                    const optionText = `${options[j]}. ${answers[j]}`;
                    await speakText(optionText);
                    setGkQuize(prevState => ({
                        ...prevState,
                        options: [...prevState.options, optionText]
                    }));
                }

                await speakText("Choose from options A, B, C, or D");

                let answer = await takeInput();
                var k = 0;

                while (k != 3 && !answer.includes("A") && !answer.includes("B") && !answer.includes("C") && !answer.includes("D")) {
                    if (answer.includes("jarvis stop")) {
                        return;
                    }
                    await speakText("Please choose a valid option (A, B, C, or D)");
                    answer = await takeInput();
                    k++;
                }

                if (answer.includes("A")) {
                    answer = "A"
                }
                else if (answer.includes("B")) {
                    answer = "B"
                }
                else if (answer.includes("C")) {
                    answer = "C"
                }
                else if (answer.includes("D")) {
                    answer = "D"
                }
                const index = options.indexOf(answer);
                if (answers[index] === correctAnswer) {
                    setGkQuize({ ...gkQuiz, correctAns: correctAnswer })
                    await speakText("Your answer is correct");
                    score++;
                } else {
                    setGkQuize({ ...gkQuiz, correctAns: correctAnswer })
                    await speakText("Your answer is incorrect");
                }
                await speakText("Correct option is" + correctAnswer);

                if (i < data.length - 1) {
                    await speakText("Next Question");
                }
            }
            await speakText(`Your Score is ${score}`);
            return setListen(true);
        } catch (error) {
            console.error("Error fetching quiz questions:", error);
            await speakText("Oops! Something went wrong while fetching quiz questions. Please try again later.");
            return setListen(true);
        }
    }

    // Function to shuffle an array (Fisher-Yates algorithm)
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    async function numberGussing() {
        const secretNumber = Math.floor(Math.random() * 10) + 1;
        let attempts = 0;

        await speakText("Welcome to the Number Guessing Game! Try to guess the secret number between 1 and 10. You have only 3 attempts.");

        let answer = await takeInput();

        while (attempts !== 2 && answer.match(/\d+/g) !== secretNumber) {
            if (answer.includes("jarvis stop")) {
                return;
            } else if (answer.match(/\d+/g) < secretNumber) {
                await speakText("Too low!");
            } else if (answer.match(/\d+/g) > secretNumber) {
                await speakText("Too high!");
            } else {
                await speakText("Please enter a valid number.");
            }
            await speakText("Please choose a number.");
            answer = await takeInput();
            attempts++;
        }

        if (parseInt(answer) === secretNumber) {
            await speakText("Congratulations! You guessed the correct number!");
        } else {
            await speakText(`Sorry, you're out of attempts. The correct number was ${secretNumber}.`);
        }

        return setListen(true);
    }

    return (
        <>
            {gkQuiz && showwindow ? (
                <div className="bg-gray-200 p-4 m-4 rounded">
                    <h3 className="text-lg font-bold mb-2">Que. {gkQuiz.question}</h3>
                    <ul className=" list-none">
                        {gkQuiz.options.map((option, index) => (
                            <li key={index} className="list-disc ml-4">{option}</li>
                        ))}
                    </ul>
                    <p className=" text-base bg-green-400 bg-opacity-15 px-2 py-4">{gkQuiz.correctAns}</p>
                </div>
            ) : null}
        </>
    )
}

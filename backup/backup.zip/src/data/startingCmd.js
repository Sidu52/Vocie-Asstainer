const name = "Jarvis";
const cmd = [
    `${name}`,
    `Hy ${name}`,
    `Hello ${name}`,
]

//Greeating
const greeatingCmd = [
    "Hyy Jarvis *Goodmorning",
    "Hyy Jarvis *Goodafternoon",
    "Hyy Jarvis *Goodevening",
]

export { cmd, greeatingCmd };
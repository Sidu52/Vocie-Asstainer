// import React from 'react'

// export default function card() {
//     return (
//         <div className="card">
//             <p className="heading">Popular this month</p>
//             <p>Powered By</p>
//             <p>Uiverse</p>
//         </div>
//     )
// }
